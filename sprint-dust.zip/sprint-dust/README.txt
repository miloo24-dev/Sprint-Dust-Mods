Salin build.gradle + settings.gradle + gradle wrapper dari proyek Bedrock Particles
(26.3 tidak pakai mappings, jadi nama kelas = nama Mojang). Taruh folder src/ ini
dan fabric.mod.json di dalamnya, ganti id/nama, lalu: ./gradlew build
Hasil jar: build/libs/
