package id.sprintdust;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Client-only: dust under the feet of sprinting players. Nothing else. */
public class SprintDustClient implements ClientModInitializer {

    private static final int INTERVAL_TICKS = 2;   // spawn every N ticks
    private static final int PARTICLES_PER_SPAWN = 2;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientLevel level = client.level;
            if (level == null || client.isPaused()) return;
            if (level.getGameTime() % INTERVAL_TICKS != 0) return;

            for (AbstractClientPlayer p : level.players()) {
                if (!p.isSprinting() || !p.onGround() || p.isInWater() || p.isPassenger()
                        || p.isSpectator() || p.isInvisible()) continue;

                BlockPos below = BlockPos.containing(p.getX(), p.getY() - 0.2, p.getZ());
                BlockState state = level.getBlockState(below);
                if (state.isAir() || state.getRenderShape() == RenderShape.INVISIBLE) continue;

                RandomSource r = p.getRandom();
                Vec3 move = p.getDeltaMovement();
                for (int i = 0; i < PARTICLES_PER_SPAWN; i++) {
                    double x = p.getX() - move.x * 2.0 + (r.nextDouble() - 0.5) * 0.4;
                    double y = p.getY() + 0.1;
                    double z = p.getZ() - move.z * 2.0 + (r.nextDouble() - 0.5) * 0.4;
                    level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, state),
                            x, y, z,
                            -move.x * 0.2 + (r.nextDouble() - 0.5) * 0.04,
                            0.04 + r.nextDouble() * 0.04,
                            -move.z * 0.2 + (r.nextDouble() - 0.5) * 0.04);
                }
            }
        });
    }
}
