package id.sprintdust;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Client-only: dust under the feet of sprinting players. Nothing else. */
public class SprintDustClient implements ClientModInitializer {

    private static final int INTERVAL_TICKS = 2;        // spawn every N ticks
    private static final int PARTICLES_PER_SPAWN = 2;
    private static final double MIN_SPEED = 0.08;       // blocks/tick; filters "sprinting into a wall"
    private static final double MAX_SPEED = 1.5;        // blocks/tick; filters teleports

    // We measure movement ourselves: other players' getDeltaMovement() is unreliable on the client.
    private final Map<UUID, Vec3> lastPos = new HashMap<>();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientLevel level = client.level;
            if (level == null) {
                lastPos.clear();
                return;
            }
            if (client.isPaused()) return;

            boolean spawnTick = level.getGameTime() % INTERVAL_TICKS == 0;
            Set<UUID> seen = new HashSet<>();

            for (AbstractClientPlayer p : level.players()) {
                UUID id = p.getUUID();
                Vec3 now = p.position();
                Vec3 prev = lastPos.put(id, now);
                seen.add(id);

                if (!spawnTick || prev == null) continue;
                if (!p.isSprinting() || !p.onGround() || p.isInWater() || p.isInLava()
                        || p.isPassenger() || p.isSpectator() || p.isInvisible()) continue;

                double dx = now.x - prev.x;
                double dz = now.z - prev.z;
                double speed = Math.sqrt(dx * dx + dz * dz);
                if (speed < MIN_SPEED || speed > MAX_SPEED) continue;

                BlockPos below = BlockPos.containing(now.x, now.y - 0.2, now.z);
                BlockState state = level.getBlockState(below);
                if (state.isAir() || state.getRenderShape() == RenderShape.INVISIBLE) continue;

                RandomSource r = p.getRandom();
                for (int i = 0; i < PARTICLES_PER_SPAWN; i++) {
                    level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, state),
                            now.x - dx * 2.0 + (r.nextDouble() - 0.5) * 0.4,
                            now.y + 0.1,
                            now.z - dz * 2.0 + (r.nextDouble() - 0.5) * 0.4,
                            -dx * 0.3 + (r.nextDouble() - 0.5) * 0.04,
                            0.04 + r.nextDouble() * 0.04,
                            -dz * 0.3 + (r.nextDouble() - 0.5) * 0.04);
                }
            }

            lastPos.keySet().retainAll(seen); // drop players who left / unloaded
        });
    }
}
